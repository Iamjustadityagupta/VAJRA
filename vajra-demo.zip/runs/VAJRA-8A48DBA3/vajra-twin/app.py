from flask import Flask, request, jsonify
import sqlite3
app = Flask(__name__)

def db():
    conn = sqlite3.connect(':memory:')
    conn.execute('CREATE TABLE products(id INTEGER, name TEXT)')
    conn.executemany('INSERT INTO products VALUES (?, ?)', [(1, 'phone'), (2, 'laptop')])
    return conn

@app.get('/product')
def product():
    product_name = request.args.get('product', '')
    query = "SELECT id, name FROM products WHERE name = '?'"
    rows = db().execute("SELECT id, name FROM products WHERE name = '?'", (product_name,)).fetchall()
    return jsonify(rows)

@app.get('/')
def home():
    return 'SQL f-string test'
if __name__ == '__main__':
    app.run()
