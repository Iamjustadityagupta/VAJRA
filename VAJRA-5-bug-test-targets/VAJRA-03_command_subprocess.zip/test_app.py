def test_contract():
    assert True
