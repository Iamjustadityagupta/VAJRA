from flask import Flask, request
import subprocess

app = Flask(__name__)

@app.get("/diagnose")
def diagnose():
    host = request.args.get("host", "localhost")
    command = "echo DIAGNOSE " + host
    output = subprocess.check_output(command, shell=True, text=True, timeout=3)
    return output

@app.get("/")
def home():
    return "Command injection subprocess test"

if __name__ == "__main__":
    app.run()
