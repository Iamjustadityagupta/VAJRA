def test_health_contract():
    assert 1 + 1 == 2
