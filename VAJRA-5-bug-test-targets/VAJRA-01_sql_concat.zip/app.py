from flask import Flask, request, jsonify
import sqlite3

app = Flask(__name__)

def db():
    conn = sqlite3.connect(":memory:")
    conn.execute("CREATE TABLE users(id INTEGER, name TEXT)")
    conn.executemany("INSERT INTO users VALUES (?, ?)", [(1, "alice"), (2, "bob")])
    return conn

@app.get("/lookup")
def lookup():
    name = request.args.get("name", "")
    query = "SELECT id, name FROM users WHERE name = '" + name + "'"
    rows = db().execute(query).fetchall()
    return jsonify({"users": [dict(zip(("id", "name"), row)) for row in rows]})

@app.get("/")
def home():
    return "SQL concat test"

if __name__ == "__main__":
    app.run()
