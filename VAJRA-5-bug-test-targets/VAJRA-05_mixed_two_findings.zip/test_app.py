def test_existing_functionality():
    assert isinstance("VAJRA", str)
    assert len("VAJRA") == 5
