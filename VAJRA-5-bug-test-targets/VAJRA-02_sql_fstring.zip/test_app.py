def test_basic():
    assert "product".upper() == "PRODUCT"
