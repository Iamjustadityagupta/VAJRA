from flask import Flask, request
import os

app = Flask(__name__)

@app.get("/healthcheck")
def healthcheck():
    target = request.args.get("target", "localhost")
    command = "echo HEALTH " + target
    os.system(command)
    return "healthcheck complete"

@app.get("/")
def home():
    return "Command injection os.system test"

if __name__ == "__main__":
    app.run()
