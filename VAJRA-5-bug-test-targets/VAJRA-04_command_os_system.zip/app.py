from flask import Flask, request
import subprocess

app = Flask(__name__)

@app.get("/healthcheck")
def healthcheck():
    target = request.args.get("target", "localhost")
    subprocess.run(
        ["echo", "HEALTH", target],
        shell=False,
        check=False,
        capture_output=True,
        text=True,
    )
    return "healthcheck complete"

@app.get("/")
def home():
    return "Command injection os.system test"

if __name__ == "__main__":
    app.run()
