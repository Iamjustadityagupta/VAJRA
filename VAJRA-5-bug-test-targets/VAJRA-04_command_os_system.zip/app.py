from flask import Flask, request
import os
import tempfile

app = Flask(__name__)

@app.get("/healthcheck")
def healthcheck():
    target = request.args.get("target", "localhost")
    command = "echo HEALTH " + target

    output_file = tempfile.NamedTemporaryFile(delete=False)
    output_file.close()

    os.system(command + " > " + output_file.name)

    with open(output_file.name, "r", encoding="utf-8") as f:
        output = f.read()

    os.unlink(output_file.name)

    return output

@app.get("/")
def home():
    return "Command injection os.system test"

if __name__ == "__main__":
    app.run()