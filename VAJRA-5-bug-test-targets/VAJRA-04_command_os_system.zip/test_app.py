def test_contract():
    assert 2 * 3 == 6
