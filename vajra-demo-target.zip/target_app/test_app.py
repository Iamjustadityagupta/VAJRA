from app import user

# Lightweight regression target: endpoint logic remains available after patching.
def test_app_imports():
    assert callable(user)
